$(document).ready(function(){
    $('#navbar_toggeler').on('click', function(e){
      $('.carousel_text').toggleClass('d-none');
    });
});
